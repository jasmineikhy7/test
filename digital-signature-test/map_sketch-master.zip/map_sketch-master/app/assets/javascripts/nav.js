$(document).ready(function() {
  if (window.location.pathname == "/") {
    $(function() {
      var header = $(".navbar");
      $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
          header.addClass("scrolled");
        } else {
          header.removeClass("scrolled");
        }
      });
    });
  }
});
