module DrawingsHelper
end
