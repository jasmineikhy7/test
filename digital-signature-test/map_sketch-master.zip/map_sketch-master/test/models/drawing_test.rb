require 'test_helper'

class DrawingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
